﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        // Pedir dos valores al usuario
        Console.WriteLine("Introduzca el primer valor: ");
        string valor1 = Console.ReadLine();

        Console.WriteLine("Introduzca el segundo valor: ");
        string valor2 = Console.ReadLine();

        // Sumar los valores usando el método
        int resultado = SumarValores(valor1, valor2);

        // Mostrar el resultado
        if (resultado != -1)
        {
            Console.WriteLine("La suma de los valores es: " + resultado);
        }
    }

    private static int SumarValores(string valor1, string valor2)
    {
        int resultado;

        try
        {
            // Validar que las cadenas no estén vacías
            if (string.IsNullOrEmpty(valor1) || string.IsNullOrEmpty(valor2))
            {
                throw new ArgumentException("Los valores no pueden estar vacíos.");
            }

            // Convertir las cadenas a enteros
            int numero1 = int.Parse(valor1);
            int numero2 = int.Parse(valor2);

            // Sumar los valores
            resultado = numero1 + numero2;
        }
        catch (FormatException ex)
        {
            // Mostrar mensaje de error si no se pueden convertir a enteros
            Console.WriteLine("Error: Los valores introducidos no son números válidos.");
            Console.WriteLine(ex.Message);

            // Devolver un valor por defecto (por ejemplo, -1) en caso de error
            resultado = -1;
        }
        catch (ArgumentException ex)
        {
            // Mostrar mensaje de error si las cadenas están vacías
            Console.WriteLine("Error: " + ex.Message);

            // Devolver un valor por defecto (por ejemplo, -1) en caso de error
            resultado = -1;
        }
        finally
        {
            // Mostrar un mensaje al final, independientemente del éxito o fallo
            Console.WriteLine("La operación de suma ha finalizado.");
        }

        return resultado;
    }
}
