﻿using System;
using System.Collections.Generic;

public class Program
{
    static List<Puntaje> puntajes = new List<Puntaje>();

    static void Main(string[] args)
    {
        // Mostrar mensaje de bienvenida
        Console.WriteLine("¡Bienvenido al juego!");

        // Solicitar datos al usuario
        while (true)
        {
            Console.WriteLine("Ingrese su nombre: ");
            string nombreJugador = Console.ReadLine();

            int puntaje;
            while (true)
            {
                Console.WriteLine("Ingrese su puntaje: ");
                string puntajeStr = Console.ReadLine();
                if (int.TryParse(puntajeStr, out puntaje) && puntaje >= 0)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Por favor, ingrese un puntaje válido (número positivo).");
                }
            }

            AgregarPuntaje(nombreJugador, puntaje);

            Console.WriteLine("¿Desea ingresar otro puntaje? (s/n)");
            string respuesta = Console.ReadLine();

            if (respuesta.ToLower() != "s")
            {
                break;
            }
        }

        // Mostrar puntaje más alto
        MostrarPuntajeMasAlto();

        // Mostrar mensaje de despedida
        Console.WriteLine("¡Gracias por jugar!");
    }

    static void AgregarPuntaje(string nombreJugador, int puntaje)
    {
        puntajes.Add(new Puntaje(nombreJugador, puntaje));
    }

    static void MostrarPuntajeMasAlto()
    {
        // Calcular puntaje más alto
        int puntajeMaximo = 0;
        string jugadorRecord = "";
        foreach (Puntaje p in puntajes)
        {
            if (p.PuntajeValor > puntajeMaximo)
            {
                puntajeMaximo = p.PuntajeValor;
                jugadorRecord = p.NombreJugador;
            }
        }

        // Mostrar mensaje
        if (puntajeMaximo > 0)
        {
            Console.WriteLine("¡La puntuación más alta es {0}!", puntajeMaximo);
            Console.WriteLine("La puntuación más alta fue lograda por {0}.", jugadorRecord);
        }
        else
        {
            Console.WriteLine("Aún no hay ningún puntaje registrado.");
        }
    }
}

public class Puntaje
{
    public Puntaje(string nombreJugador, int puntaje)
    {
        NombreJugador = nombreJugador;
        PuntajeValor = puntaje;
    }

    public string NombreJugador { get; private set; }
    public int PuntajeValor { get; private set; }
}

