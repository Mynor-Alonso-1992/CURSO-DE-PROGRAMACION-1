﻿using System;
using System.Collections.Generic;

public class Program
{
    private static List<Usuario> usuarios = new List<Usuario>();

    public static void Main(string[] args)
    {
        int opcion;

        do
        {
            Console.WriteLine("**Sistema de inicio de sesión**");
            Console.WriteLine("-------------------------");
            Console.WriteLine("1. Registrarse");
            Console.WriteLine("2. Iniciar sesión");
            Console.WriteLine("3. Salir");
            Console.WriteLine("-------------------------");
            Console.WriteLine("Introduzca una opción: ");

            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    RegistrarUsuario();
                    break;
                case 2:
                    IniciarSesion();
                    break;
                case 3:
                    Console.WriteLine("Saliendo del sistema...");
                    break;
                default:
                    Console.WriteLine("Opción no válida. Intentelo de nuevo.");
                    break;
            }

        } while (opcion != 3);
    }

    private static void RegistrarUsuario()
    {
        string nombreUsuario, contrasena;

        Console.WriteLine("**Registro de usuario**");
        Console.WriteLine("-------------------------");

        Console.WriteLine("Introduzca su nombre de usuario: ");
        nombreUsuario = Console.ReadLine();

        Console.WriteLine("Introduzca su contraseña: ");
        contrasena = Console.ReadLine();

        // Validar que el nombre de usuario no esté ya registrado

        if (UsuarioExiste(nombreUsuario))
        {
            Console.WriteLine("El nombre de usuario ya está registrado. Intentelo de nuevo.");
            return;
        }

        // Crear un nuevo usuario y agregarlo a la lista

        Usuario nuevoUsuario = new Usuario(nombreUsuario, contrasena);
        usuarios.Add(nuevoUsuario);

        Console.WriteLine("Usuario registrado correctamente.");
    }

    private static void IniciarSesion()
    {
        string nombreUsuario, contrasena;

        Console.WriteLine("**Inicio de sesión**");
        Console.WriteLine("-------------------------");

        Console.WriteLine("Introduzca su nombre de usuario: ");
        nombreUsuario = Console.ReadLine();

        Console.WriteLine("Introduzca su contraseña: ");
        contrasena = Console.ReadLine();

        // Buscar el usuario en la lista

        Usuario usuario = usuarios.Find(x => x.NombreUsuario == nombreUsuario);

        // Validar si el usuario existe y la contraseña es correcta

        if (usuario == null || usuario.Contrasena != contrasena)
        {
            Console.WriteLine("Usuario o contraseña incorrectos. Intentelo de nuevo.");
            return;
        }

        Console.WriteLine("Inicio de sesión correcto. Bienvenido " + usuario.NombreUsuario + "!");
    }

    private static bool UsuarioExiste(string nombreUsuario)
    {
        return usuarios.Exists(x => x.NombreUsuario == nombreUsuario);
    }
}

public class Usuario
{
    public string NombreUsuario { get; set; }
    public string Contrasena { get; set; }

    public Usuario(string nombreUsuario, string contrasena)
    {
        NombreUsuario = nombreUsuario;
        Contrasena = contrasena;
    }
}
